
"use strict";

let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestNestedService = require('./TestNestedService.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestEmpty = require('./TestEmpty.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let SendBytes = require('./SendBytes.js')
let AddTwoInts = require('./AddTwoInts.js')

module.exports = {
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestNestedService: TestNestedService,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestRequestOnly: TestRequestOnly,
  TestRequestAndResponse: TestRequestAndResponse,
  TestResponseOnly: TestResponseOnly,
  TestEmpty: TestEmpty,
  TestArrayRequest: TestArrayRequest,
  SendBytes: SendBytes,
  AddTwoInts: AddTwoInts,
};
