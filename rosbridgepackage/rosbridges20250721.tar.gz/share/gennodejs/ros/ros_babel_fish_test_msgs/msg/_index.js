
"use strict";

let TestArray = require('./TestArray.js');
let TestSubArray = require('./TestSubArray.js');
let TestMessage = require('./TestMessage.js');
let SimpleTestActionFeedback = require('./SimpleTestActionFeedback.js');
let SimpleTestFeedback = require('./SimpleTestFeedback.js');
let SimpleTestResult = require('./SimpleTestResult.js');
let SimpleTestActionGoal = require('./SimpleTestActionGoal.js');
let SimpleTestGoal = require('./SimpleTestGoal.js');
let SimpleTestActionResult = require('./SimpleTestActionResult.js');
let SimpleTestAction = require('./SimpleTestAction.js');

module.exports = {
  TestArray: TestArray,
  TestSubArray: TestSubArray,
  TestMessage: TestMessage,
  SimpleTestActionFeedback: SimpleTestActionFeedback,
  SimpleTestFeedback: SimpleTestFeedback,
  SimpleTestResult: SimpleTestResult,
  SimpleTestActionGoal: SimpleTestActionGoal,
  SimpleTestGoal: SimpleTestGoal,
  SimpleTestActionResult: SimpleTestActionResult,
  SimpleTestAction: SimpleTestAction,
};
