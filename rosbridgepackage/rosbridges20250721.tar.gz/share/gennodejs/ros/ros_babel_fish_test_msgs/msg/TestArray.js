// Auto-generated. Do not edit!

// (in-package ros_babel_fish_test_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TestSubArray = require('./TestSubArray.js');

//-----------------------------------------------------------

class TestArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.bools = null;
      this.uint8s = null;
      this.uint16s = null;
      this.uint32s = null;
      this.uint64s = null;
      this.int8s = null;
      this.int16s = null;
      this.int32s = null;
      this.int64s = null;
      this.float32s = null;
      this.float64s = null;
      this.times = null;
      this.durations = null;
      this.strings = null;
      this.subarrays_fixed = null;
      this.subarrays = null;
    }
    else {
      if (initObj.hasOwnProperty('bools')) {
        this.bools = initObj.bools
      }
      else {
        this.bools = [];
      }
      if (initObj.hasOwnProperty('uint8s')) {
        this.uint8s = initObj.uint8s
      }
      else {
        this.uint8s = [];
      }
      if (initObj.hasOwnProperty('uint16s')) {
        this.uint16s = initObj.uint16s
      }
      else {
        this.uint16s = new Array(32).fill(0);
      }
      if (initObj.hasOwnProperty('uint32s')) {
        this.uint32s = initObj.uint32s
      }
      else {
        this.uint32s = [];
      }
      if (initObj.hasOwnProperty('uint64s')) {
        this.uint64s = initObj.uint64s
      }
      else {
        this.uint64s = [];
      }
      if (initObj.hasOwnProperty('int8s')) {
        this.int8s = initObj.int8s
      }
      else {
        this.int8s = [];
      }
      if (initObj.hasOwnProperty('int16s')) {
        this.int16s = initObj.int16s
      }
      else {
        this.int16s = [];
      }
      if (initObj.hasOwnProperty('int32s')) {
        this.int32s = initObj.int32s
      }
      else {
        this.int32s = [];
      }
      if (initObj.hasOwnProperty('int64s')) {
        this.int64s = initObj.int64s
      }
      else {
        this.int64s = new Array(32).fill(0);
      }
      if (initObj.hasOwnProperty('float32s')) {
        this.float32s = initObj.float32s
      }
      else {
        this.float32s = [];
      }
      if (initObj.hasOwnProperty('float64s')) {
        this.float64s = initObj.float64s
      }
      else {
        this.float64s = new Array(16).fill(0);
      }
      if (initObj.hasOwnProperty('times')) {
        this.times = initObj.times
      }
      else {
        this.times = [];
      }
      if (initObj.hasOwnProperty('durations')) {
        this.durations = initObj.durations
      }
      else {
        this.durations = new Array(12).fill(0);
      }
      if (initObj.hasOwnProperty('strings')) {
        this.strings = initObj.strings
      }
      else {
        this.strings = [];
      }
      if (initObj.hasOwnProperty('subarrays_fixed')) {
        this.subarrays_fixed = initObj.subarrays_fixed
      }
      else {
        this.subarrays_fixed = new Array(10).fill(new TestSubArray());
      }
      if (initObj.hasOwnProperty('subarrays')) {
        this.subarrays = initObj.subarrays
      }
      else {
        this.subarrays = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestArray
    // Serialize message field [bools]
    bufferOffset = _arraySerializer.bool(obj.bools, buffer, bufferOffset, null);
    // Serialize message field [uint8s]
    bufferOffset = _arraySerializer.uint8(obj.uint8s, buffer, bufferOffset, null);
    // Check that the constant length array field [uint16s] has the right length
    if (obj.uint16s.length !== 32) {
      throw new Error('Unable to serialize array field uint16s - length must be 32')
    }
    // Serialize message field [uint16s]
    bufferOffset = _arraySerializer.uint16(obj.uint16s, buffer, bufferOffset, 32);
    // Serialize message field [uint32s]
    bufferOffset = _arraySerializer.uint32(obj.uint32s, buffer, bufferOffset, null);
    // Serialize message field [uint64s]
    bufferOffset = _arraySerializer.uint64(obj.uint64s, buffer, bufferOffset, null);
    // Serialize message field [int8s]
    bufferOffset = _arraySerializer.int8(obj.int8s, buffer, bufferOffset, null);
    // Serialize message field [int16s]
    bufferOffset = _arraySerializer.int16(obj.int16s, buffer, bufferOffset, null);
    // Serialize message field [int32s]
    bufferOffset = _arraySerializer.int32(obj.int32s, buffer, bufferOffset, null);
    // Check that the constant length array field [int64s] has the right length
    if (obj.int64s.length !== 32) {
      throw new Error('Unable to serialize array field int64s - length must be 32')
    }
    // Serialize message field [int64s]
    bufferOffset = _arraySerializer.int64(obj.int64s, buffer, bufferOffset, 32);
    // Serialize message field [float32s]
    bufferOffset = _arraySerializer.float32(obj.float32s, buffer, bufferOffset, null);
    // Check that the constant length array field [float64s] has the right length
    if (obj.float64s.length !== 16) {
      throw new Error('Unable to serialize array field float64s - length must be 16')
    }
    // Serialize message field [float64s]
    bufferOffset = _arraySerializer.float64(obj.float64s, buffer, bufferOffset, 16);
    // Serialize message field [times]
    bufferOffset = _arraySerializer.time(obj.times, buffer, bufferOffset, null);
    // Check that the constant length array field [durations] has the right length
    if (obj.durations.length !== 12) {
      throw new Error('Unable to serialize array field durations - length must be 12')
    }
    // Serialize message field [durations]
    bufferOffset = _arraySerializer.duration(obj.durations, buffer, bufferOffset, 12);
    // Serialize message field [strings]
    bufferOffset = _arraySerializer.string(obj.strings, buffer, bufferOffset, null);
    // Check that the constant length array field [subarrays_fixed] has the right length
    if (obj.subarrays_fixed.length !== 10) {
      throw new Error('Unable to serialize array field subarrays_fixed - length must be 10')
    }
    // Serialize message field [subarrays_fixed]
    obj.subarrays_fixed.forEach((val) => {
      bufferOffset = TestSubArray.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [subarrays]
    // Serialize the length for message field [subarrays]
    bufferOffset = _serializer.uint32(obj.subarrays.length, buffer, bufferOffset);
    obj.subarrays.forEach((val) => {
      bufferOffset = TestSubArray.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestArray
    let len;
    let data = new TestArray(null);
    // Deserialize message field [bools]
    data.bools = _arrayDeserializer.bool(buffer, bufferOffset, null)
    // Deserialize message field [uint8s]
    data.uint8s = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [uint16s]
    data.uint16s = _arrayDeserializer.uint16(buffer, bufferOffset, 32)
    // Deserialize message field [uint32s]
    data.uint32s = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    // Deserialize message field [uint64s]
    data.uint64s = _arrayDeserializer.uint64(buffer, bufferOffset, null)
    // Deserialize message field [int8s]
    data.int8s = _arrayDeserializer.int8(buffer, bufferOffset, null)
    // Deserialize message field [int16s]
    data.int16s = _arrayDeserializer.int16(buffer, bufferOffset, null)
    // Deserialize message field [int32s]
    data.int32s = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int64s]
    data.int64s = _arrayDeserializer.int64(buffer, bufferOffset, 32)
    // Deserialize message field [float32s]
    data.float32s = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [float64s]
    data.float64s = _arrayDeserializer.float64(buffer, bufferOffset, 16)
    // Deserialize message field [times]
    data.times = _arrayDeserializer.time(buffer, bufferOffset, null)
    // Deserialize message field [durations]
    data.durations = _arrayDeserializer.duration(buffer, bufferOffset, 12)
    // Deserialize message field [strings]
    data.strings = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [subarrays_fixed]
    len = 10;
    data.subarrays_fixed = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.subarrays_fixed[i] = TestSubArray.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [subarrays]
    // Deserialize array length for message field [subarrays]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.subarrays = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.subarrays[i] = TestSubArray.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.bools.length;
    length += object.uint8s.length;
    length += 4 * object.uint32s.length;
    length += 8 * object.uint64s.length;
    length += object.int8s.length;
    length += 2 * object.int16s.length;
    length += 4 * object.int32s.length;
    length += 4 * object.float32s.length;
    length += 8 * object.times.length;
    object.strings.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.subarrays_fixed.forEach((val) => {
      length += TestSubArray.getMessageSize(val);
    });
    object.subarrays.forEach((val) => {
      length += TestSubArray.getMessageSize(val);
    });
    return length + 588;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ros_babel_fish_test_msgs/TestArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ee9eb275c64b3e6194c3de5d36ffcdaf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool[] bools
    uint8[] uint8s
    uint16[32] uint16s
    uint32[] uint32s
    uint64[] uint64s
    int8[] int8s
    int16[] int16s
    int32[] int32s
    int64[32] int64s#Comment
    float32[] float32s
     float64[16] float64s
    time[] times
    duration[12] durations
    string[] strings
    TestSubArray[10] subarrays_fixed
    TestSubArray[] subarrays
    
    
    ================================================================================
    MSG: ros_babel_fish_test_msgs/TestSubArray
    int32[] ints
    string[] strings
    time[42] times
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestArray(null);
    if (msg.bools !== undefined) {
      resolved.bools = msg.bools;
    }
    else {
      resolved.bools = []
    }

    if (msg.uint8s !== undefined) {
      resolved.uint8s = msg.uint8s;
    }
    else {
      resolved.uint8s = []
    }

    if (msg.uint16s !== undefined) {
      resolved.uint16s = msg.uint16s;
    }
    else {
      resolved.uint16s = new Array(32).fill(0)
    }

    if (msg.uint32s !== undefined) {
      resolved.uint32s = msg.uint32s;
    }
    else {
      resolved.uint32s = []
    }

    if (msg.uint64s !== undefined) {
      resolved.uint64s = msg.uint64s;
    }
    else {
      resolved.uint64s = []
    }

    if (msg.int8s !== undefined) {
      resolved.int8s = msg.int8s;
    }
    else {
      resolved.int8s = []
    }

    if (msg.int16s !== undefined) {
      resolved.int16s = msg.int16s;
    }
    else {
      resolved.int16s = []
    }

    if (msg.int32s !== undefined) {
      resolved.int32s = msg.int32s;
    }
    else {
      resolved.int32s = []
    }

    if (msg.int64s !== undefined) {
      resolved.int64s = msg.int64s;
    }
    else {
      resolved.int64s = new Array(32).fill(0)
    }

    if (msg.float32s !== undefined) {
      resolved.float32s = msg.float32s;
    }
    else {
      resolved.float32s = []
    }

    if (msg.float64s !== undefined) {
      resolved.float64s = msg.float64s;
    }
    else {
      resolved.float64s = new Array(16).fill(0)
    }

    if (msg.times !== undefined) {
      resolved.times = msg.times;
    }
    else {
      resolved.times = []
    }

    if (msg.durations !== undefined) {
      resolved.durations = msg.durations;
    }
    else {
      resolved.durations = new Array(12).fill(0)
    }

    if (msg.strings !== undefined) {
      resolved.strings = msg.strings;
    }
    else {
      resolved.strings = []
    }

    if (msg.subarrays_fixed !== undefined) {
      resolved.subarrays_fixed = new Array(10)
      for (let i = 0; i < resolved.subarrays_fixed.length; ++i) {
        if (msg.subarrays_fixed.length > i) {
          resolved.subarrays_fixed[i] = TestSubArray.Resolve(msg.subarrays_fixed[i]);
        }
        else {
          resolved.subarrays_fixed[i] = new TestSubArray();
        }
      }
    }
    else {
      resolved.subarrays_fixed = new Array(10).fill(new TestSubArray())
    }

    if (msg.subarrays !== undefined) {
      resolved.subarrays = new Array(msg.subarrays.length);
      for (let i = 0; i < resolved.subarrays.length; ++i) {
        resolved.subarrays[i] = TestSubArray.Resolve(msg.subarrays[i]);
      }
    }
    else {
      resolved.subarrays = []
    }

    return resolved;
    }
};

module.exports = TestArray;
