// Auto-generated. Do not edit!

// (in-package ros_babel_fish_test_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TestSubArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ints = null;
      this.strings = null;
      this.times = null;
    }
    else {
      if (initObj.hasOwnProperty('ints')) {
        this.ints = initObj.ints
      }
      else {
        this.ints = [];
      }
      if (initObj.hasOwnProperty('strings')) {
        this.strings = initObj.strings
      }
      else {
        this.strings = [];
      }
      if (initObj.hasOwnProperty('times')) {
        this.times = initObj.times
      }
      else {
        this.times = new Array(42).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestSubArray
    // Serialize message field [ints]
    bufferOffset = _arraySerializer.int32(obj.ints, buffer, bufferOffset, null);
    // Serialize message field [strings]
    bufferOffset = _arraySerializer.string(obj.strings, buffer, bufferOffset, null);
    // Check that the constant length array field [times] has the right length
    if (obj.times.length !== 42) {
      throw new Error('Unable to serialize array field times - length must be 42')
    }
    // Serialize message field [times]
    bufferOffset = _arraySerializer.time(obj.times, buffer, bufferOffset, 42);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestSubArray
    let len;
    let data = new TestSubArray(null);
    // Deserialize message field [ints]
    data.ints = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [strings]
    data.strings = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [times]
    data.times = _arrayDeserializer.time(buffer, bufferOffset, 42)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.ints.length;
    object.strings.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 344;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ros_babel_fish_test_msgs/TestSubArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ddb462bd2b9200ff53b217730f85e82c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32[] ints
    string[] strings
    time[42] times
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestSubArray(null);
    if (msg.ints !== undefined) {
      resolved.ints = msg.ints;
    }
    else {
      resolved.ints = []
    }

    if (msg.strings !== undefined) {
      resolved.strings = msg.strings;
    }
    else {
      resolved.strings = []
    }

    if (msg.times !== undefined) {
      resolved.times = msg.times;
    }
    else {
      resolved.times = new Array(42).fill(0)
    }

    return resolved;
    }
};

module.exports = TestSubArray;
