// Auto-generated. Do not edit!

// (in-package ros_babel_fish_test_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TestMessage {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.b = null;
      this.ui8 = null;
      this.ui16 = null;
      this.ui32 = null;
      this.ui64 = null;
      this.i8 = null;
      this.i16 = null;
      this.i32 = null;
      this.i64 = null;
      this.f32 = null;
      this.f64 = null;
      this.str = null;
      this.t = null;
      this.d = null;
      this.point_arr = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('b')) {
        this.b = initObj.b
      }
      else {
        this.b = false;
      }
      if (initObj.hasOwnProperty('ui8')) {
        this.ui8 = initObj.ui8
      }
      else {
        this.ui8 = 0;
      }
      if (initObj.hasOwnProperty('ui16')) {
        this.ui16 = initObj.ui16
      }
      else {
        this.ui16 = 0;
      }
      if (initObj.hasOwnProperty('ui32')) {
        this.ui32 = initObj.ui32
      }
      else {
        this.ui32 = 0;
      }
      if (initObj.hasOwnProperty('ui64')) {
        this.ui64 = initObj.ui64
      }
      else {
        this.ui64 = 0;
      }
      if (initObj.hasOwnProperty('i8')) {
        this.i8 = initObj.i8
      }
      else {
        this.i8 = 0;
      }
      if (initObj.hasOwnProperty('i16')) {
        this.i16 = initObj.i16
      }
      else {
        this.i16 = 0;
      }
      if (initObj.hasOwnProperty('i32')) {
        this.i32 = initObj.i32
      }
      else {
        this.i32 = 0;
      }
      if (initObj.hasOwnProperty('i64')) {
        this.i64 = initObj.i64
      }
      else {
        this.i64 = 0;
      }
      if (initObj.hasOwnProperty('f32')) {
        this.f32 = initObj.f32
      }
      else {
        this.f32 = 0.0;
      }
      if (initObj.hasOwnProperty('f64')) {
        this.f64 = initObj.f64
      }
      else {
        this.f64 = 0.0;
      }
      if (initObj.hasOwnProperty('str')) {
        this.str = initObj.str
      }
      else {
        this.str = '';
      }
      if (initObj.hasOwnProperty('t')) {
        this.t = initObj.t
      }
      else {
        this.t = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('d')) {
        this.d = initObj.d
      }
      else {
        this.d = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('point_arr')) {
        this.point_arr = initObj.point_arr
      }
      else {
        this.point_arr = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TestMessage
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [b]
    bufferOffset = _serializer.bool(obj.b, buffer, bufferOffset);
    // Serialize message field [ui8]
    bufferOffset = _serializer.uint8(obj.ui8, buffer, bufferOffset);
    // Serialize message field [ui16]
    bufferOffset = _serializer.uint16(obj.ui16, buffer, bufferOffset);
    // Serialize message field [ui32]
    bufferOffset = _serializer.uint32(obj.ui32, buffer, bufferOffset);
    // Serialize message field [ui64]
    bufferOffset = _serializer.uint64(obj.ui64, buffer, bufferOffset);
    // Serialize message field [i8]
    bufferOffset = _serializer.int8(obj.i8, buffer, bufferOffset);
    // Serialize message field [i16]
    bufferOffset = _serializer.int16(obj.i16, buffer, bufferOffset);
    // Serialize message field [i32]
    bufferOffset = _serializer.int32(obj.i32, buffer, bufferOffset);
    // Serialize message field [i64]
    bufferOffset = _serializer.int64(obj.i64, buffer, bufferOffset);
    // Serialize message field [f32]
    bufferOffset = _serializer.float32(obj.f32, buffer, bufferOffset);
    // Serialize message field [f64]
    bufferOffset = _serializer.float64(obj.f64, buffer, bufferOffset);
    // Serialize message field [str]
    bufferOffset = _serializer.string(obj.str, buffer, bufferOffset);
    // Serialize message field [t]
    bufferOffset = _serializer.time(obj.t, buffer, bufferOffset);
    // Serialize message field [d]
    bufferOffset = _serializer.duration(obj.d, buffer, bufferOffset);
    // Serialize message field [point_arr]
    // Serialize the length for message field [point_arr]
    bufferOffset = _serializer.uint32(obj.point_arr.length, buffer, bufferOffset);
    obj.point_arr.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TestMessage
    let len;
    let data = new TestMessage(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [b]
    data.b = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [ui8]
    data.ui8 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [ui16]
    data.ui16 = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [ui32]
    data.ui32 = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [ui64]
    data.ui64 = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [i8]
    data.i8 = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [i16]
    data.i16 = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [i32]
    data.i32 = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [i64]
    data.i64 = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [f32]
    data.f32 = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [f64]
    data.f64 = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [str]
    data.str = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [t]
    data.t = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [d]
    data.d = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [point_arr]
    // Deserialize array length for message field [point_arr]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.point_arr = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.point_arr[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.str);
    length += 24 * object.point_arr.length;
    return length + 67;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ros_babel_fish_test_msgs/TestMessage';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3d5931b1835a6d921ed35d5d2d59b889';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    bool b
    uint8 ui8
    uint16 ui16
    uint32 ui32
    uint64 ui64
    int8 i8
    int16 i16
    int32 i32
    
    int64 i64
    float32 f32 # Comment
    float64 f64#Also a comment but closer
    string str## Two comment signs # and a third
    time t
    duration d
    geometry_msgs/Point[] point_arr # more comment
    
    bool FLAG1 =1
    bool FLAG2= 0
    bool FLAG3=True
    bool FLAG4 = False
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TestMessage(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.b !== undefined) {
      resolved.b = msg.b;
    }
    else {
      resolved.b = false
    }

    if (msg.ui8 !== undefined) {
      resolved.ui8 = msg.ui8;
    }
    else {
      resolved.ui8 = 0
    }

    if (msg.ui16 !== undefined) {
      resolved.ui16 = msg.ui16;
    }
    else {
      resolved.ui16 = 0
    }

    if (msg.ui32 !== undefined) {
      resolved.ui32 = msg.ui32;
    }
    else {
      resolved.ui32 = 0
    }

    if (msg.ui64 !== undefined) {
      resolved.ui64 = msg.ui64;
    }
    else {
      resolved.ui64 = 0
    }

    if (msg.i8 !== undefined) {
      resolved.i8 = msg.i8;
    }
    else {
      resolved.i8 = 0
    }

    if (msg.i16 !== undefined) {
      resolved.i16 = msg.i16;
    }
    else {
      resolved.i16 = 0
    }

    if (msg.i32 !== undefined) {
      resolved.i32 = msg.i32;
    }
    else {
      resolved.i32 = 0
    }

    if (msg.i64 !== undefined) {
      resolved.i64 = msg.i64;
    }
    else {
      resolved.i64 = 0
    }

    if (msg.f32 !== undefined) {
      resolved.f32 = msg.f32;
    }
    else {
      resolved.f32 = 0.0
    }

    if (msg.f64 !== undefined) {
      resolved.f64 = msg.f64;
    }
    else {
      resolved.f64 = 0.0
    }

    if (msg.str !== undefined) {
      resolved.str = msg.str;
    }
    else {
      resolved.str = ''
    }

    if (msg.t !== undefined) {
      resolved.t = msg.t;
    }
    else {
      resolved.t = {secs: 0, nsecs: 0}
    }

    if (msg.d !== undefined) {
      resolved.d = msg.d;
    }
    else {
      resolved.d = {secs: 0, nsecs: 0}
    }

    if (msg.point_arr !== undefined) {
      resolved.point_arr = new Array(msg.point_arr.length);
      for (let i = 0; i < resolved.point_arr.length; ++i) {
        resolved.point_arr[i] = geometry_msgs.msg.Point.Resolve(msg.point_arr[i]);
      }
    }
    else {
      resolved.point_arr = []
    }

    return resolved;
    }
};

// Constants for message
TestMessage.Constants = {
  FLAG1: true,
  FLAG2: false,
  FLAG3: true,
  FLAG4: false,
}

module.exports = TestMessage;
