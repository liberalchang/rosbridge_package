^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosbridge_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.17 (2023-09-27)
--------------------

0.11.16 (2022-10-18)
--------------------
* Bump minimum required cmake version. (`#814 <https://github.com/RobotWebTools/rosbridge_suite/issues/814>`_)
* Contributors: Hans-Joachim Krauch

0.11.15 (2022-10-06)
--------------------

0.11.14 (2022-06-13)
--------------------
* Small fixes (`#681 <https://github.com/RobotWebTools/rosbridge_suite/issues/681>`_)
* Contributors: Matthijs van der Burgh

0.11.13 (2020-12-08)
--------------------

0.11.12 (2020-11-25)
--------------------

0.11.11 (2020-11-24)
--------------------

0.11.10 (2020-09-08)
--------------------

0.11.9 (2020-05-27)
-------------------

0.11.8 (2020-05-21)
-------------------

0.11.7 (2020-05-13)
-------------------

0.11.6 (2020-04-29)
-------------------

0.11.5 (2020-04-08)
-------------------

0.11.4 (2020-02-20)
-------------------

0.11.3 (2019-08-07)
-------------------

0.11.2 (2019-07-08)
-------------------

0.11.1 (2019-05-08)
-------------------

0.11.0 (2019-03-29)
-------------------
* Additional client information websocket (`#393 <https://github.com/RobotWebTools/rosbridge_suite/issues/393>`_)
  * Add package rosbridge_msgs.
  * rosbridge_server: Publish additional information about connected clients.
  * rosbridge_server: Make ClientManager's add_client/remove_client methods thread safe.
  * rosbridge_server: Rm unnecessary publishing.
  * rosbridge_msgs: Cleanup/fix dependencies.
* Contributors: Hans-Joachim Krauch
